package com.example.food;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class login {
	
	public static final String db_url="jdbc:mysql://localhost:3306/assignment1";
	public static final String user="root";
	public static final String pass="pass@word1";
    public static final String query="select * from login where email=?AND user_name=?";
    
    AllFood af=new AllFood();
    InsertFood ifi=new InsertFood();
    UpdateFood uf=new UpdateFood();
    DeleteFood df= new DeleteFood();
    
    
    public void loginuser() {
    try(Connection conl=DriverManager.getConnection(db_url, user, pass);
    		PreparedStatement ps=conl.prepareStatement(query);){
    	
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter email address: ");
        String emaill=sc.next();
        System.out.println("Enter user name:");
        String userl=sc.next();
        ps.setString(1, emaill);
        ps.setString(2, userl);
        ps.executeQuery();
        System.out.println("login successfully");
        
        System.out.println("Enter 1 for Add food\n 2 for--> View ALL Food \n 3 for-->Update Food availablity\n 4 for--> Delete Food");
        Scanner scf=new Scanner(System.in);
        int scc=scf.nextInt();
        switch(scc) {
        case 1:
        	// insert method()
        	ifi.foodInsert();
        	break;
        case 2:
        	//view all food
        	af.foodDetails();
        	break;
        case 3:
        	//update all food
        	uf.foodUpdate();
        	break;
        case 4:
        	//delete food item
        	df.deleteFood();
        	break;
        	
        	default:
        	{
        		System.out.println("Enter correct choice:");
        	}
      
        }
    	
    }
    catch(SQLException e) {
    	e.printStackTrace();
    }
	
    }				
}


