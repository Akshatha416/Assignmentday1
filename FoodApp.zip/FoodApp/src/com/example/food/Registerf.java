package com.example.food;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Registerf {

	
	static final String db_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String query1="insert into login (email,user_name,upwd) values (?,?,?)";
	
//	public static void main(String[] args) {
//		
//		  ;}
		
		public static void m1() {
           
             
             try(Connection conn=DriverManager.getConnection(db_url,user,pass);
            		 PreparedStatement ps=conn.prepareStatement(query1);
            		 )
             {
            	 
            	 System.out.println("Registration page:");
            	 
            	 Scanner sc=new Scanner(System.in);
            	 System.out.println("Enter email:");
            	 String emailr=sc.next();
            	 System.out.println("Enter username:");
            	 String username=sc.next();
            	 System.out.println("Enter password");
            	 String password=sc.next();
            	 ps.setString(1, emailr);
            	 ps.setString(2, username);
            	 ps.setString(3, password);
            	 ps.executeUpdate();
            	 System.out.println("Registration Done Successfull");
             }
             catch(SQLException e) {e.printStackTrace();
            		 }
	}
	}


