package com.example.food;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertFood {
	
	public static final String db_url="jdbc:mysql://localhost:3306/assignment1";
	public static final String user="root";
	public static final String pass="pass@word1";
	public static final String queryi="insert into food(food_id,food_name,food_status) values(?,?,?)";
	
	public void foodInsert() {
		try(Connection coni=DriverManager.getConnection(db_url, user, pass);
				PreparedStatement psi=coni.prepareStatement(queryi);){
			Scanner sci=new Scanner(System.in);
			System.out.println("enter Food Id:");
			int fid=sci.nextInt();
			psi.setInt(1, fid);
			System.out.println("Enter Food Name:");
			String fname=sci.next();
			psi.setString(2, fname);
			System.out.println("Enter Food Status");
			String fstatus=sci.next();
			psi.setString(3, fstatus);
			psi.executeUpdate();
			System.out.println("Food updates updated successfully");
		}
		
		catch(SQLException e) {e.printStackTrace();}
	}
	

}
