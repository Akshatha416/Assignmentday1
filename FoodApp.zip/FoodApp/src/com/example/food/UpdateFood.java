package com.example.food;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateFood {
	public static final String db_url="jdbc:mysql://localhost:3306/assignment1";
	public static final String user="root";
	public static final String root="pass@word1";
	public static final String queryu="update food set food_status=? where food_name=?";
public void foodUpdate() {
	try(Connection conu=DriverManager.getConnection(db_url, user, db_url);
			PreparedStatement psu=conu.prepareStatement(queryu);){
		Scanner scu=new Scanner(System.in);
		System.out.println("Enter the Food status:");
		String fstatus=scu.next();
		System.out.println("Enter the food Name:");
		String fname=scu.next();
		
		psu.setString(1, fstatus);
		psu.setString(2, fname);
		psu.executeUpdate();
		System.out.println("Updated Successfully");
		
		
	}
	
	
	catch(SQLException e) {e.printStackTrace();}
}
}
