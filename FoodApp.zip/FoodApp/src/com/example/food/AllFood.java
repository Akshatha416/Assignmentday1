package com.example.food;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AllFood {
	
	public static final String db_url="jdbc:mysql://localhost:3306/assignment1";
	public static final String user="root";
	public static final String pass="pass@word1";
	public static final String query1="select * from food";
	
	public void foodDetails() {
		
		System.out.println("Food Details");
		try(Connection conf=DriverManager.getConnection(db_url, user, pass);
				Statement stf=conf.createStatement();
				ResultSet rsf=stf.executeQuery(query1);){
			
			while(rsf.next()) {
			
			
			System.out.println("food_id:"+ rsf.getInt("food_id"));
			System.out.println("food name:"+ rsf.getString("food_name"));
			System.out.println("food status:"+rsf.getString("food_status"));
			}
		}
		catch(SQLException e) {e.printStackTrace();}
	}

}
