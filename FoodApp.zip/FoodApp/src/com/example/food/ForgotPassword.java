package com.example.food;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ForgotPassword {
	
	InsertFood i=new InsertFood();
	public static final String queryf="Update login set upwd=? where email=?";

	
	public void forPass() {
		System.out.println("Forgot Password");
	try(Connection conn=DriverManager.getConnection(i.db_url,i.user,i.pass);
			PreparedStatement ps=conn.prepareStatement(queryf);
			){
		
		Scanner sc3 = new Scanner(System.in);
		
		System.out.println("enter email");
		String i3=sc3.next();
		ps.setString(2, i3);
		System.out.println("enter new password:");
		String newpwd=sc3.next();
		ps.setString(1, newpwd);
		ps.executeUpdate();
		System.out.println("Successfully Set New Password:");
	}
	catch(SQLException e) 
	{
		e.printStackTrace();
	}
}
}