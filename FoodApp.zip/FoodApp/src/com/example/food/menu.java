package com.example.food;

import java.util.Scanner;

public class menu {

	public static void main(String[] args) {
		System.out.println("WELCOME TO FOOD APP:");
		
		Registerf rf=new Registerf();
		login l=new login();
		
		
		 System.out.println("Enter Choice:");
      System.out.println("select 1 for--> Registration \n select 2 for --> Login \n select 3 for--> Forgot PassWord\n");
      Scanner sc= new Scanner(System.in);
     
      int i=sc.nextInt();
      switch(i)
      {
      case 1:
    	  rf.m1();
    	  System.out.println("Now you can login :");
    	  
      case 2:
    	  l.loginuser();
    	  break;
    	  
      case 3:
    	  //forgot password
    	  break;
    	  
    	  default:
    		  
    	  {System.out.println("Enter correct Choice:");}
    	  
    	  
      
    	  
    	  
    	  //System.out.println("");
    	  
      
      }
	}

}
